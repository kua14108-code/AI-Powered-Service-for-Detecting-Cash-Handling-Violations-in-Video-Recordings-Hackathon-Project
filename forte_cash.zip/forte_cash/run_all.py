"""Один командой стартует бэкенд (8000) и интерфейс (8501):  python run_all.py"""
import os
import subprocess
import sys

env = dict(os.environ)
api = subprocess.Popen([sys.executable, "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"], env=env)
ui = subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app.py", "--server.port", "8501",
                       "--server.address", "0.0.0.0", "--browser.gatherUsageStats", "false"], env=env)
try:
    ui.wait()
finally:
    api.terminate()
    ui.terminate()
