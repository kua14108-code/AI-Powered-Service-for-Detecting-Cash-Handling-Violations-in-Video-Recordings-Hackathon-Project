"""FastAPI-бэкенд сервиса «Контроль кассовой дисциплины по видео» (ForteBank Datathon 26).

Запуск:  uvicorn main:app --host 0.0.0.0 --port 8000
Всё работает локально: OpenCV + MediaPipe (веса внутри pip-пакета). Облачных API нет.
"""
from __future__ import annotations

import json
import os
import secrets
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from core.analyzer import VideoAnalyzer
from core.catalog import CATALOG

BASE = Path(__file__).parent
DATA = Path(os.getenv("FORTE_DATA_DIR", BASE / "data"))
UPLOADS = DATA / "uploads"
JOBS = DATA / "jobs"
for d in (UPLOADS, JOBS):
    d.mkdir(parents=True, exist_ok=True)

API_KEY = os.getenv("FORTE_API_KEY", "forte-datathon-26-demo-key")
MAX_BYTES = int(os.getenv("FORTE_MAX_UPLOAD_MB", "200")) * 1024 * 1024
KEEP_VIDEOS = os.getenv("FORTE_KEEP_VIDEOS", "0") == "1"   # по умолчанию видео жюри удаляется после анализа
ALLOWED_EXT = {".mov", ".mp4", ".m4v"}

app = FastAPI(
    title="Cash Discipline AI — ForteBank Datathon 26",
    version="1.0.0",
    description="Локальный анализ видеозаписей кассы: вердикт, таймкоды, кадры-доказательства, нормативная привязка.",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_analyzer = VideoAnalyzer()
_pool = ThreadPoolExecutor(max_workers=1)     # модель сегментации не потокобезопасна -> одна задача за раз
_jobs: dict[str, dict] = {}
_lock = threading.Lock()


def verify_key(x_api_key: str | None = Header(default=None, alias="X-API-Key")):
    if not x_api_key or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key")


def _save(job_id: str):
    with _lock:
        job = dict(_jobs[job_id])
    (JOBS / f"{job_id}.json").write_text(json.dumps(job, ensure_ascii=False), encoding="utf-8")


def _load(job_id: str) -> dict | None:
    with _lock:
        if job_id in _jobs:
            return dict(_jobs[job_id])
    p = JOBS / f"{job_id}.json"
    if p.exists():
        job = json.loads(p.read_text(encoding="utf-8"))
        with _lock:
            _jobs[job_id] = job
        return dict(job)
    return None


def _run(job_id: str, path: Path):
    def progress(stage: str, p: float):
        with _lock:
            _jobs[job_id].update(stage=stage, progress=round(float(p), 3))
    started = time.time()
    try:
        res = _analyzer.analyze(str(path), progress)
        with _lock:
            _jobs[job_id].update(
                status="done", stage="Готово", progress=1.0,
                verdict=res["verdict"], violations=res["violations"], meta=res["_meta"],
                elapsed_sec=round(time.time() - started, 1),
            )
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        with _lock:
            _jobs[job_id].update(status="failed", error=str(e))
    finally:
        _save(job_id)
        if not KEEP_VIDEOS:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass


@app.get("/health")
def health():
    return {"status": "ok", "local_only": True, "engine": "opencv+mediapipe"}


@app.post("/api/v1/analyze", dependencies=[Depends(verify_key)])
async def analyze(file: UploadFile = File(...)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, f"Ожидается видео .mov (получено '{ext or 'без расширения'}')")
    job_id = uuid.uuid4().hex[:8]
    path = UPLOADS / f"{job_id}{ext}"
    size = 0
    with path.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_BYTES:
                out.close(); path.unlink(missing_ok=True)
                raise HTTPException(413, "Файл слишком большой")
            out.write(chunk)
    if size == 0:
        path.unlink(missing_ok=True)
        raise HTTPException(400, "Пустой файл")
    with _lock:
        _jobs[job_id] = {"job_id": job_id, "status": "processing", "stage": "В очереди",
                         "progress": 0.0, "filename": file.filename, "created": time.time()}
    _pool.submit(_run, job_id, path)
    return {"job_id": job_id, "status": "processing"}


@app.get("/api/v1/jobs/{job_id}", dependencies=[Depends(verify_key)])
def get_job(job_id: str):
    job = _load(job_id)
    if job is None:
        raise HTTPException(404, "job not found")
    if job["status"] == "processing":
        return {"job_id": job_id, "status": "processing",
                "stage": job.get("stage"), "progress": job.get("progress", 0.0)}
    if job["status"] == "failed":
        return {"job_id": job_id, "status": "failed", "error": job.get("error", "unknown error")}
    # точный формат ответа из ТЗ (+ поле regulation внутри нарушения)
    return {"job_id": job_id, "status": "done",
            "verdict": job["verdict"], "violations": job["violations"]}


@app.get("/api/v1/jobs/{job_id}/meta", dependencies=[Depends(verify_key)])
def get_meta(job_id: str):
    """Служебные данные для интерфейса (таймлайн, калибровка). Не входит в формат жюри."""
    job = _load(job_id)
    if job is None or job["status"] != "done":
        raise HTTPException(404, "job not ready")
    return {"job_id": job_id, "elapsed_sec": job.get("elapsed_sec"), **job["meta"]}


@app.get("/api/v1/catalog", dependencies=[Depends(verify_key)])
def catalog():
    return [{"rule_id": v.rule_id, "title": v.title, "regulation": v.regulation,
             "implemented": v.implemented, "visual_cue": v.visual_cue} for v in CATALOG.values()]
