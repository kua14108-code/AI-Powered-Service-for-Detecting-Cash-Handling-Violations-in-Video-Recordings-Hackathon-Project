"""Streamlit-интерфейс (корпоративная палитра: бургунди #800020 на белом).
Запуск:  streamlit run app.py
Интерфейс общается с бэкендом ТОЛЬКО через публичный API — так же, как жюри."""
from __future__ import annotations

import base64
import json
import os
import time

import requests
import streamlit as st

API_URL = os.getenv("FORTE_API_URL", "http://127.0.0.1:8000").rstrip("/")
API_KEY = os.getenv("FORTE_API_KEY", "forte-datathon-26-demo-key")
HDR = {"X-API-Key": API_KEY}
STAGES = [
    ("Приём и проверка видео", "Приём видео"),
    ("Кадровый срез OpenCV", "Кадровый срез OpenCV"),
    ("Сегментация людей (локальная модель)", "Поиск людей в кадре"),
    ("Проверка по правилам НБ РК", "Проверка по правилам НБ РК"),
    ("Генерация кадров-доказательств", "Кадры-доказательства"),
]

st.set_page_config(page_title="Контроль кассовой дисциплины", page_icon="🏦", layout="wide")

CSS = """
<style>
:root{--b:#800020;--b2:#5c0017;--bl:#f8eef0;--g:#1c7c4d;--r:#b3122f;--t:#1f1a1c;--m:#7b6f73}
html,body,[class*="css"]{font-family:-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
.stApp{background:#fff;color:var(--t)}
header[data-testid="stHeader"]{background:transparent}
.block-container{padding-top:1.2rem;max-width:1250px}
.hero{background:linear-gradient(120deg,var(--b) 0%,var(--b2) 100%);border-radius:22px;padding:26px 32px;color:#fff;
  display:flex;justify-content:space-between;align-items:center;box-shadow:0 14px 34px rgba(128,0,32,.25);margin-bottom:18px}
.hero h1{margin:0;font-size:28px;font-weight:700;letter-spacing:-.3px;color:#fff}
.hero p{margin:6px 0 0;opacity:.85;font-size:14px}
.badge{display:inline-block;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.3);border-radius:999px;
  padding:5px 13px;font-size:12px;margin-left:8px;color:#fff}
.card{background:#fff;border:1px solid #eadde0;border-radius:18px;padding:20px 22px;box-shadow:0 4px 18px rgba(60,0,15,.05);margin-bottom:14px}
.verdict{border-radius:18px;padding:20px 26px;color:#fff;display:flex;align-items:center;gap:18px;margin:6px 0 16px}
.verdict.bad{background:linear-gradient(120deg,#b3122f,#800020)}
.verdict.ok{background:linear-gradient(120deg,#1c7c4d,#13573a)}
.verdict .ic{font-size:38px}.verdict h2{margin:0;color:#fff;font-size:24px}.verdict p{margin:2px 0 0;opacity:.9;font-size:14px}
.steps{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 14px}
.step{flex:1;min-width:150px;border:1px solid #eadde0;border-radius:14px;padding:11px 13px;font-size:13px;color:var(--m);background:#fff}
.step.act{border-color:var(--b);color:var(--b);background:var(--bl);font-weight:600;animation:pulse 1.2s infinite}
.step.done{border-color:#bfe3cf;color:var(--g);background:#f1faf5}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(128,0,32,.35)}100%{box-shadow:0 0 0 12px rgba(128,0,32,0)}}
.pbar{height:12px;background:#f1e4e7;border-radius:99px;overflow:hidden}
.pbar>div{height:100%;background:linear-gradient(90deg,#a3233f,#800020);border-radius:99px;transition:width .4s}
.tl{position:relative;height:64px;background:linear-gradient(#faf3f4,#faf3f4);border:1px solid #eadde0;border-radius:14px;margin:8px 0 4px}
.tl .ax{position:absolute;left:14px;right:14px;top:30px;height:4px;background:#e6d3d7;border-radius:3px}
.tl .mk{position:absolute;top:14px;width:16px;height:16px;margin-left:-8px;border-radius:50%;background:var(--r);border:3px solid #fff;
  box-shadow:0 0 0 2px var(--r)}
.tl .mk span{position:absolute;top:26px;left:50%;transform:translateX(-50%);font-size:11px;color:var(--b);font-weight:700;white-space:nowrap}
.tl .run{position:absolute;top:29px;height:6px;background:rgba(179,18,47,.45);border-radius:3px}
.tl .tick{position:absolute;top:44px;font-size:10px;color:var(--m);transform:translateX(-50%)}
.chip{display:inline-block;background:var(--bl);color:var(--b);border-radius:999px;padding:4px 12px;font-size:12px;font-weight:600}
.reg{background:#faf3f4;border-left:4px solid var(--b);border-radius:8px;padding:9px 12px;font-size:13px;color:#4a3d41;margin-top:8px}
.small{color:var(--m);font-size:12.5px}
div[data-testid="stFileUploaderDropzone"]{border:2px dashed var(--b);border-radius:18px;background:var(--bl);padding:26px}
div.stButton>button,div.stDownloadButton>button{background:var(--b);color:#fff;border:0;border-radius:12px;padding:.6rem 1.4rem;font-weight:600}
div.stButton>button:hover{background:var(--b2);color:#fff}
table.tbl{width:100%;border-collapse:collapse;font-size:13.5px;margin:6px 0 14px}
table.tbl th{background:var(--b);color:#fff;text-align:left;padding:8px 12px}
table.tbl td{border-bottom:1px solid #eadde0;padding:8px 12px;vertical-align:top}
button[data-baseweb="tab"]{font-weight:600}
button[data-baseweb="tab"][aria-selected="true"]{color:var(--b)}
div[data-baseweb="tab-highlight"]{background:var(--b)!important}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)
st.markdown(
    "<div class='hero'><div><h1>🏦 Контроль кассовой дисциплины по видео</h1>"
    "<p>AI-сервис выявляет визуально наблюдаемые признаки нарушений: тип, таймкод, кадры-доказательства, норма НБ РК</p></div>"
    "<div><span class='badge'>100% локально</span><span class='badge'>без облачных API</span>"
    "<span class='badge'>Datathon 26</span></div></div>",
    unsafe_allow_html=True,
)


def api_alive() -> bool:
    try:
        return requests.get(f"{API_URL}/health", timeout=2).ok
    except requests.RequestException:
        return False


def fmt(t: float) -> str:
    return f"{int(t // 60)}:{t % 60:04.1f}"


def stepper(stage: str, p: float):
    names = [s[0] for s in STAGES]
    cur = names.index(stage) if stage in names else (len(names) - 1 if p >= 1 else 0)
    html = "<div class='steps'>"
    for i, (_, label) in enumerate(STAGES):
        cls = "done" if (i < cur or p >= 1) else ("act" if i == cur else "")
        mark = "✓ " if cls == "done" else ("● " if cls == "act" else "")
        html += f"<div class='step {cls}'>{mark}{label}</div>"
    html += "</div>"
    html += f"<div class='pbar'><div style='width:{int(p*100)}%'></div></div>"
    html += f"<p class='small'>Идёт анализ: {int(p*100)}%</p>"
    return html


def timeline_html(duration: float, violations: list, meta: dict) -> str:
    duration = max(duration, 1.0)
    pos = lambda t: 14 + (t / duration) * 0  # noqa: E731 (используем проценты ниже)
    h = "<div class='tl'><div class='ax'></div>"
    for a, b in meta.get("away_runs", []):
        l = a / duration * 100; w = max(0.8, (b - a) / duration * 100)
        h += f"<div class='run' style='left:calc(14px + (100% - 28px)*{l/100});width:calc((100% - 28px)*{w/100})'></div>"
    for v in violations:
        l = v["timecode_sec"] / duration
        h += (f"<div class='mk' style='left:calc(14px + (100% - 28px)*{l})'><span>{fmt(v['timecode_sec'])}</span></div>")
    for k in range(0, 5):
        t = duration * k / 4
        h += f"<div class='tick' style='left:calc(14px + (100% - 28px)*{k/4})'>{fmt(t)}</div>"
    return h + "</div>"


tab_an, tab_api, tab_about = st.tabs(["Анализ видео", "API Inspector (для жюри)", "О решении"])

# ============================================================= АНАЛИЗ
with tab_an:
    if not api_alive():
        st.error(f"Бэкенд недоступен по адресу {API_URL}. Запустите: `uvicorn main:app --port 8000` "
                 "(или `python run_all.py`, который стартует оба сервиса).")
        st.stop()

    c1, c2 = st.columns([3, 2], gap="large")
    with c1:
        up = st.file_uploader("Перетащите видео кассы (.mov) или выберите файл", type=["mov", "mp4"],
                              label_visibility="visible")
    with c2:
        st.markdown(
            "<div class='card'><b>Как это работает</b><ol class='small' style='padding-left:18px;margin:8px 0 0'>"
            "<li>Видео режется на кадры (OpenCV)</li><li>Локальная модель находит силуэты людей</li>"
            "<li>Сцена калибруется сама: кто кассир, где его место</li>"
            "<li>Правила НБ РК → события с таймкодом</li><li>Кадры-доказательства и норма</li></ol></div>",
            unsafe_allow_html=True)

    if up is not None:
        st.video(up.getvalue(), format="video/quicktime" if up.name.lower().endswith(".mov") else "video/mp4")
        if st.button("🔍 Запустить анализ", use_container_width=False):
            r = requests.post(f"{API_URL}/api/v1/analyze", headers=HDR,
                              files={"file": (up.name, up.getvalue(), "video/quicktime")}, timeout=120)
            if not r.ok:
                st.error(f"Ошибка API {r.status_code}: {r.text}")
            else:
                job_id = r.json()["job_id"]
                box = st.empty()
                t0 = time.time()
                while True:
                    j = requests.get(f"{API_URL}/api/v1/jobs/{job_id}", headers=HDR, timeout=30).json()
                    if j["status"] == "processing":
                        box.markdown(stepper(j.get("stage", ""), float(j.get("progress", 0))), unsafe_allow_html=True)
                        time.sleep(0.6)
                        continue
                    break
                box.empty()
                if j["status"] == "failed":
                    st.error(f"Анализ не выполнен: {j.get('error')}")
                else:
                    meta = requests.get(f"{API_URL}/api/v1/jobs/{job_id}/meta", headers=HDR, timeout=30).json()
                    st.session_state["res"] = {"job": j, "meta": meta, "video": up.getvalue(),
                                               "name": up.name, "elapsed": time.time() - t0}

    res = st.session_state.get("res")
    if res:
        j, meta = res["job"], res["meta"]
        vs = j["violations"]
        if j["verdict"] == "violation":
            st.markdown(f"<div class='verdict bad'><div class='ic'>⚠️</div><div><h2>Обнаружены признаки возможных нарушений: {len(vs)}</h2>"
                        f"<p>Результат — подсказка для проверяющего, а не дисциплинарное заключение. Файл: {res['name']}</p></div></div>",
                        unsafe_allow_html=True)
        else:
            st.markdown("<div class='verdict ok'><div class='ic'>✅</div><div><h2>Нарушение не обнаружено</h2>"
                        "<p>Сервис не нашёл визуальных признаков нарушений из своего перечня (см. «О решении» — что именно он умеет видеть).</p></div></div>",
                        unsafe_allow_html=True)
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Длительность", fmt(meta["duration_sec"]))
        m2.metric("Кадров проанализировано", meta["samples"])
        m3.metric("Время анализа", f"{meta.get('elapsed_sec', res['elapsed']):.0f} с")
        m4.metric("Кассир найден", "да" if meta["cashier_calibrated"] else "нет")

        st.markdown("#### Таймлайн событий")
        st.markdown(timeline_html(meta["duration_sec"], vs, meta), unsafe_allow_html=True)
        if vs:
            labels = [f"{fmt(v['timecode_sec'])} — {v['type']}" for v in vs]
            sel = st.selectbox("Перейти к событию в плеере", range(len(vs)), format_func=lambda i: labels[i])
            st.video(res["video"], start_time=max(0, int(vs[sel]["timecode_sec"]) - 2),
                     format="video/quicktime" if res["name"].lower().endswith(".mov") else "video/mp4")
            st.markdown("#### Кадры-доказательства")
            for i, v in enumerate(vs, 1):
                st.markdown(f"<div class='card'><span class='chip'>#{i} · {fmt(v['timecode_sec'])}</span> "
                            f"&nbsp;<b style='font-size:17px'>{v['type']}</b>", unsafe_allow_html=True)
                cols = st.columns(len(v["evidence_frames"]))
                for col, fr in zip(cols, v["evidence_frames"]):
                    col.image(base64.b64decode(fr["image_base64"]), caption=f"{fr['timestamp_sec']:.1f} с",
                              use_container_width=True)
                st.write(v["description"])
                st.markdown(f"<div class='reg'>⚖️ <b>Нормативная привязка:</b> {v['regulation']}</div></div>",
                            unsafe_allow_html=True)

# ============================================================= API INSPECTOR
with tab_api:
    st.markdown("### Что видит система жюри")
    st.code(f'curl -X POST {API_URL}/api/v1/analyze \\\n     -H "X-API-Key: <ключ>" -F "file=@video_017.mov"\n\n'
            f'curl {API_URL}/api/v1/jobs/<job_id> -H "X-API-Key: <ключ>"', language="bash")
    res = st.session_state.get("res")
    if res:
        full = {"job_id": res["job"]["job_id"], "status": "done",
                "verdict": res["job"]["verdict"], "violations": res["job"]["violations"]}
        show_b64 = st.toggle("Показывать base64 кадров целиком", value=False)
        view = json.loads(json.dumps(full))
        if not show_b64:
            for v in view["violations"]:
                for f in v["evidence_frames"]:
                    f["image_base64"] = f["image_base64"][:40] + f"…[{len(f['image_base64'])} симв.]"
        st.json(view)
        st.download_button("⬇ Скачать полный JSON", json.dumps(full, ensure_ascii=False, indent=2),
                           file_name=f"result_{full['job_id']}.json", mime="application/json")
    else:
        st.info("Загрузите и проанализируйте видео — здесь появится JSON в точном формате ТЗ.")
    st.markdown("#### Эндпоинты")
    st.markdown(
        "<table class='tbl'><tr><th>Метод</th><th>Путь</th><th>Назначение</th></tr>"
        "<tr><td>POST</td><td>/api/v1/analyze</td><td>загрузка .mov → job_id</td></tr>"
        "<tr><td>GET</td><td>/api/v1/jobs/{job_id}</td><td>статус и результат (формат ТЗ)</td></tr>"
        "<tr><td>GET</td><td>/api/v1/jobs/{job_id}/meta</td><td>служебные данные таймлайна (UI)</td></tr>"
        "<tr><td>GET</td><td>/api/v1/catalog</td><td>справочник типов нарушений</td></tr></table>",
        unsafe_allow_html=True)
    try:
        cat = requests.get(f"{API_URL}/api/v1/catalog", headers=HDR, timeout=5).json()
        rows = "".join(
            f"<tr><td>{c['title']}</td><td>{c['regulation']}</td>"
            f"<td>{'✅ да' if c['implemented'] else '— нет'}</td></tr>" for c in cat)
        st.markdown("#### Справочник типов (из API)")
        st.markdown(f"<table class='tbl'><tr><th>Тип</th><th>Норма</th><th>Распознаётся</th></tr>{rows}</table>",
                    unsafe_allow_html=True)
    except requests.RequestException:
        pass

# ============================================================= О РЕШЕНИИ
with tab_about:
    st.markdown("""
### Подход
* **Локально.** OpenCV + MediaPipe (Apache-2.0). Веса моделей лежат внутри pip-пакета; интернет при обработке не нужен.
* **Без идентификации лиц** (требование ТЗ). Используются только силуэты людей.
* **Самокалибровка сцены:** кассир определяется по первым секундам записи, правила работают в координатах его рабочего места — поэтому не завязаны на конкретный ракурс камеры.
* **Консервативность:** лучше промолчать, чем выдумать нарушение. В описании — только то, что видно; невидимое (проводки, пересчёт) не утверждается.

### Что распознаётся сейчас
1. **Уход кассира с рабочего места** — Правила № 231, п. 22.
2. **Доступ посторонних лиц в кассовую зону** — Правила № 231, п. 75; Правила № 14, п. 8; п. 16 пп. 1), 5).

### Что пока НЕ распознаётся (честно)
Нарушения, требующие распознавания предметов и действий рук (пересчёт купюр, проверка подлинности, документ клиента,
телефон, еда/напитки, ключи и т. п.). Для них нужен детектор объектов/действий, обученный на размеченных роликах; в
текущей сборке такого нет — см. README, раздел «Ограничения».

### Нормативные источники
* Правила № 231 — Постановление Правления НБРК от 29.11.2019 № 231 (adilet.zan.kz/rus/docs/V1900019680)
* Правила № 14 — Постановление Правления НБРК от 24.02.2020 № 14 (adilet.zan.kz/rus/docs/V2000020075)
""")
