"""Оценка качества на размеченном датасете (open_labels.xlsx + папка с .mov).

    python evaluate.py --videos ./dataset --labels open_labels.xlsx [--tol 5]

Метки: «нарушение / без нарушения» + таймстемп («22 секунда», «1минута 8 секунда»).
Файлы сопоставляются по имени (X-1 ↔ X-1.mov; кириллическая «Х» приравнивается к латинской «X»).
Считает точность вердикта (критерий 1), ложные срабатывания / пропуски и ошибку таймкода (критерий 2).
"""
import argparse
import re
from pathlib import Path

import openpyxl

from core.analyzer import VideoAnalyzer


def norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower().replace("х", "x"))


def parse_ts(s):
    if not s:
        return None
    m = re.search(r"(\d+)\s*мин", s); sec = re.search(r"(\d+)\s*сек", s)
    return (int(m.group(1)) * 60 if m else 0) + (int(sec.group(1)) if sec else 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--videos", required=True); ap.add_argument("--labels", required=True)
    ap.add_argument("--tol", type=float, default=5.0, help="допуск таймкода, с")
    a = ap.parse_args()
    labels = {}
    for name, ts, verdict in list(openpyxl.load_workbook(a.labels).active.iter_rows(values_only=True))[1:]:
        labels[norm(name)] = (verdict == "нарушение", parse_ts(ts))
    files = {}
    for f in Path(a.videos).glob("*"):
        if f.suffix.lower() in (".mov", ".mp4"):
            m = re.search(r"[xх]\s*-?\s*\d+", f.stem.lower())
            files[norm(m.group(0)) if m else norm(f.stem)] = f
    an = VideoAnalyzer()
    tp = fp = fn = tn = 0; errs = []
    for key, (is_v, ts) in sorted(labels.items()):
        f = files.get(key)
        if not f:
            print(f"{key:6s} — видео не найдено"); continue
        res = an.analyze(str(f))
        pred = res["verdict"] == "violation"
        times = [v["timecode_sec"] for v in res["violations"]]
        err = min((abs(t - ts) for t in times), default=None) if (is_v and ts is not None) else None
        if is_v and pred: tp += 1
        elif is_v and not pred: fn += 1
        elif not is_v and pred: fp += 1
        else: tn += 1
        if err is not None: errs.append(err)
        print(f"{key:6s} истина={'НАР' if is_v else '---'} ({ts}) прогноз={'НАР' if pred else '---'} {times}"
              + ("" if err is None else f" |Δt|={err:.1f}"))
    n = tp + fp + fn + tn
    if n:
        print(f"\nТочность вердикта: {(tp+tn)/n:.0%}  (TP={tp} TN={tn} FP={fp} FN={fn})")
    if errs:
        print(f"Таймкод: медианная ошибка {sorted(errs)[len(errs)//2]:.1f} с, в допуске ±{a.tol:.0f} с: "
              f"{sum(e<=a.tol for e in errs)}/{len(errs)}")


if __name__ == "__main__":
    main()
