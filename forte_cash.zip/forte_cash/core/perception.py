"""Слой восприятия: локальная сегментация людей (MediaPipe Selfie Segmentation,
веса лежат внутри pip-пакета, интернет не нужен) + классическое CV (OpenCV).

Лица НЕ распознаются и не идентифицируются (требование ТЗ, FAQ п.29):
используется только маска силуэта человека.
"""
from __future__ import annotations
import cv2
import numpy as np
import mediapipe as mp

ANALYSIS_LONG_SIDE = 960               # длинная сторона рабочего кадра (датасет — портрет 9:16)


class PersonSegmenter:
    def __init__(self):
        self._seg = mp.solutions.selfie_segmentation.SelfieSegmentation(model_selection=0)

    def mask(self, frame_bgr: np.ndarray, tile: int = 270, stride: int = 135) -> np.ndarray:
        """Вероятность 'человек' по кадру. Кадр режется на перекрывающиеся тайлы
        (модель рассчитана на портреты вблизи, поэтому на общем плане её нужно
        запускать по фрагментам); результат — максимум по тайлам."""
        h, w = frame_bgr.shape[:2]
        out = np.zeros((h, w), np.float32)
        ys = list(range(0, max(1, h - tile + 1), stride))
        xs = list(range(0, max(1, w - tile + 1), stride))
        if ys[-1] + tile < h: ys.append(h - tile)
        if xs[-1] + tile < w: xs.append(w - tile)
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        for y in ys:
            for x in xs:
                crop = rgb[y:y + tile, x:x + tile]
                r = self._seg.process(crop).segmentation_mask
                r = cv2.resize(r, (crop.shape[1], crop.shape[0]))
                np.maximum(out[y:y + tile, x:x + tile], r, out=out[y:y + tile, x:x + tile])
        return out


def normalize_gain(frame_bgr: np.ndarray) -> np.ndarray:
    """Компенсация резких скачков экспозиции камеры (в датасете бывают затемнения)."""
    f = frame_bgr.astype(np.float32)
    m = float(f.mean())
    if m < 1: return frame_bgr
    return np.clip(f * (110.0 / m), 0, 255).astype(np.uint8)


def desk_box(frame_bgr: np.ndarray):
    """Грубый поиск стола по цвету светлого дерева (HSV). Возвращает bbox и маску."""
    hsv = cv2.cvtColor(normalize_gain(frame_bgr), cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (5, 55, 90), (25, 190, 255))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n <= 1: return None, m
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    x, y, w, h, a = st[i]
    if a < 0.01 * m.size: return None, m
    return (int(x), int(y), int(w), int(h)), (lab == i).astype(np.uint8) * 255
