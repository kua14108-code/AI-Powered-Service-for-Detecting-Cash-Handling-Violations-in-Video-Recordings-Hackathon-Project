"""Анализ видео кассира: полностью локально (OpenCV + MediaPipe, без облака).

Конвейер
  1. Кадровый срез: ~3 кадра/с, нормализация размера и экспозиции.
  2. Сегментация силуэтов людей (MediaPipe Selfie Segmentation по перекрывающимся тайлам).
     Лица не распознаются и не идентифицируются.
  3. Сцена калибруется САМА по первым секундам видео: «якорь» кассира — крупный силуэт,
     стабильно присутствующий в начале. Все правила работают в координатах якоря, поэтому
     не привязаны к конкретному ракурсу камеры.
  4. Правила (core/catalog.py) -> события с таймкодом.
  5. Кадры-доказательства (1–3 JPEG, base64) вырезаются в полном разрешении по таймкоду.
"""
from __future__ import annotations

import base64
import math
import os
from dataclasses import dataclass, field
from typing import Callable, Optional

import cv2
import numpy as np

from .catalog import CATALOG
from .perception import PersonSegmenter, ANALYSIS_LONG_SIDE

ProgressCb = Callable[[str, float], None]

SAMPLE_FPS = float(os.getenv("FORTE_SAMPLE_FPS", "3"))
MIN_AREA_FRAC = 0.012          # минимальная площадь «человека» (доля кадра)
ANCHOR_WINDOW_SEC = 3.0        # окно калибровки кассира
AWAY_OVERLAP = 0.20            # доля якоря, занятая силуэтом, ниже которой кассир «ушёл»
AWAY_MIN_SEC = 3.0             # минимальная длительность отсутствия
CLOSE_FACTOR = 0.50            # «в зоне досягаемости кассира» (в размерах якоря)
CLOSE_MIN_SEC = 1.5
MULTI_MIN_SEC = 1.5            # одновременно >=2 не-кассиров


@dataclass
class Comp:
    x: int; y: int; w: int; h: int; area: int; cx: float; cy: float


@dataclass
class Sample:
    t: float
    comps: list
    valid: bool = True


@dataclass
class Event:
    rule_id: str
    t: float
    description: str
    evidence_ts: list
    boxes: dict = field(default_factory=dict)   # t -> (x,y,w,h) в координатах анализа


def _components(mask: np.ndarray, min_area: int) -> list:
    b = (mask > 0.6).astype(np.uint8)
    b = cv2.morphologyEx(b, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    b = cv2.morphologyEx(b, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, _, st, cen = cv2.connectedComponentsWithStats(b)
    out = []
    for j in range(1, n):
        x, y, w, h, a = [int(v) for v in st[j]]
        if a >= min_area:
            out.append(Comp(x, y, w, h, a, float(cen[j][0]), float(cen[j][1])))
    return out


def _inter(c: Comp, roi) -> float:
    rx, ry, rw, rh = roi
    ix = max(0, min(c.x + c.w, rx + rw) - max(c.x, rx))
    iy = max(0, min(c.y + c.h, ry + rh) - max(c.y, ry))
    return float(ix * iy)


def _runs(flags: list, times: list, min_sec: float):
    """Непрерывные отрезки True длительностью >= min_sec. flags[i] None = кадр пропущен."""
    runs, start, last = [], None, None
    for f, t in zip(flags, times):
        if f is None:
            continue
        if f:
            if start is None:
                start = t
            last = t
        else:
            if start is not None and last - start + 1.0 / SAMPLE_FPS >= min_sec:
                runs.append((start, last))
            start = None
    if start is not None and last - start + 1.0 / SAMPLE_FPS >= min_sec:
        runs.append((start, last))
    return runs


def _jpeg_b64(img: np.ndarray, max_w: int = 640, q: int = 80) -> str:
    h, w = img.shape[:2]
    if w > max_w:
        img = cv2.resize(img, (max_w, int(h * max_w / w)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, q])
    return base64.b64encode(buf.tobytes()).decode("ascii")


class VideoAnalyzer:
    def __init__(self):
        self._seg: Optional[PersonSegmenter] = None

    @property
    def seg(self) -> PersonSegmenter:
        if self._seg is None:
            self._seg = PersonSegmenter()
        return self._seg

    # ------------------------------------------------------------------ public
    def analyze(self, path: str, progress: ProgressCb = lambda s, p: None) -> dict:
        progress("Приём и проверка видео", 0.02)
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            raise ValueError("Не удалось открыть видеофайл (ожидается .mov/H.264)")
        src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if W == 0 or H == 0:
            raise ValueError("Видео не содержит кадров")
        duration = total / src_fps if total else 0.0
        scale = ANALYSIS_LONG_SIDE / float(max(W, H))
        aw, ah = int(round(W * scale)), int(round(H * scale))
        min_area = int(MIN_AREA_FRAC * aw * ah)
        progress("Кадровый срез OpenCV", 0.06)

        step = max(1, int(round(src_fps / SAMPLE_FPS)))
        samples: list[Sample] = []
        brightness: list[float] = []
        i = 0
        while True:
            if not cap.grab():
                break
            if i % step == 0:
                ok, f = cap.retrieve()
                if not ok:
                    break
                f = cv2.resize(f, (aw, ah), interpolation=cv2.INTER_AREA)
                brightness.append(float(f.mean()))
                m = self.seg.mask(f)
                samples.append(Sample(i / src_fps, _components(m, min_area)))
                if total:
                    progress("Сегментация людей (локальная модель)", 0.06 + 0.64 * min(1.0, i / total))
            i += 1
        cap.release()
        if not duration:
            duration = i / src_fps
        if not samples:
            raise ValueError("Не удалось прочитать кадры видео")

        # кадры с резким скачком экспозиции (затемнение камеры) не участвуют в выводах
        med_b = float(np.median(brightness))
        for s, b in zip(samples, brightness):
            s.valid = (0.45 * med_b) <= b <= (2.2 * med_b)

        progress("Проверка по правилам НБ РК", 0.74)
        events, meta = self._apply_rules(samples, aw, ah)

        progress("Генерация кадров-доказательств", 0.88)
        violations = self._build_violations(path, events, (aw, ah), (W, H))
        progress("Готово", 1.0)

        timeline = [
            {"t": round(s.t, 2), "people": len(s.comps), "valid": s.valid}
            for s in samples
        ]
        return {
            "verdict": "violation" if violations else "no_violation",
            "violations": violations,
            "_meta": {
                "duration_sec": round(duration, 2),
                "frame_size": [W, H],
                "analysis_size": [aw, ah],
                "samples": len(samples),
                "cashier_calibrated": meta["anchor"] is not None,
                "anchor_roi": meta["anchor"],
                "timeline": timeline,
                "away_runs": meta.get("away_runs", []),
            },
        }

    # ------------------------------------------------------------------- rules
    def _calibrate_anchor(self, samples, aw, ah):
        win = [s for s in samples if s.t < ANCHOR_WINDOW_SEC and s.valid]
        if not win:
            return None
        big = []
        for s in win:
            cs = [c for c in s.comps if c.area >= 0.009 * aw * ah]
            if cs:
                big.append(max(cs, key=lambda c: c.area))
        if len(big) < max(2, int(0.6 * len(win))):
            return None
        xs = np.median([[c.x, c.y, c.w, c.h] for c in big], axis=0)
        return tuple(int(v) for v in xs)

    def _apply_rules(self, samples, aw, ah):
        events: list[Event] = []
        anchor = self._calibrate_anchor(samples, aw, ah)
        meta = {"anchor": list(anchor) if anchor else None}
        if anchor is None:
            return events, meta
        rx, ry, rw, rh = anchor
        roi_area = float(rw * rh)
        acx, acy = rx + rw / 2.0, ry + rh / 2.0
        scale_ref = math.sqrt(rw * rh)
        times = [s.t for s in samples]

        # ---- кассир = силуэт с макс. пересечением с якорем -------------------
        cashier_comp, overlap = [], []
        for s in samples:
            best, bo = None, 0.0
            for c in s.comps:
                o = _inter(c, anchor)
                if o > bo:
                    best, bo = c, o
            cashier_comp.append(best if bo / roi_area >= 0.05 else None)
            overlap.append(bo / roi_area if best is not None else 0.0)

        # ---- D1: уход кассира ----------------------------------------------
        flags = []
        for s, o in zip(samples, overlap):
            if not s.valid:
                flags.append(None)
            else:
                flags.append(o < AWAY_OVERLAP)
        runs = _runs(flags, times, AWAY_MIN_SEC)
        meta["away_runs"] = [[round(a, 2), round(b, 2)] for a, b in runs]
        for a, b in runs:
            # последний кадр, где кассир ещё на месте, — до ухода
            prev = [s.t for s, o in zip(samples, overlap) if s.t < a and s.valid and o >= 0.5]
            t_before = prev[-1] if prev else max(0.0, a - 1.5)
            t_after = min(b, a + 2.0)
            dur = b - a + 1.0 / SAMPLE_FPS
            desc = (
                f"Силуэт кассира, присутствовавший на рабочем месте с начала записи, с {a:.1f} с "
                f"покидает зону рабочего места (зона кассира занята менее чем на "
                f"{int(AWAY_OVERLAP*100)}%) и не возвращается минимум {dur:.0f} с. "
                f"Силуэт кассира за пределами рамки рабочего места (см. кадры). Сервис не видит, было ли завершено "
                f"обслуживание клиента и остались ли ценности на столе — проверяющему нужно "
                f"посмотреть фрагмент и подтвердить нарушение."
            )
            events.append(Event("CASHIER_LEFT", a, desc, [t_before, a, t_after],
                                {t_before: anchor, a: anchor, t_after: anchor}))

        # ---- статические объекты (счётчик банкнот, мебель) исключаем ------------
        static_keys = self._static_blobs(samples)

        # ---- не-кассиры в каждом кадре ------------------------------------------
        others = []
        for s, cc in zip(samples, cashier_comp):
            lst = []
            for c in s.comps:
                if cc is not None and c is cc:
                    continue
                if _inter(c, anchor) / max(1.0, c.area) > 0.5:
                    continue
                if any(abs(c.cx - kx) < 8 and abs(c.cy - ky) < 8 for kx, ky in static_keys):
                    continue
                lst.append(c)
            others.append(lst)

        # ---- D2a: несколько посторонних одновременно -----------------------------
        flags = [None if not s.valid else (len([c for c in o if c.area >= 0.012*aw*ah]) >= 2)
                 for s, o in zip(samples, others)]
        for a, b in _runs(flags, times, MULTI_MIN_SEC):
            idx = min(range(len(samples)), key=lambda k: abs(samples[k].t - (a + b) / 2))
            boxes = {round(samples[idx].t, 2): None}
            desc = (
                f"С {a:.1f} по {b:.1f} с в кадре одновременно находятся кассир и не менее двух "
                f"других людей. Одного клиента у кассы допустимо; присутствие второго лица "
                f"в кассовой зоне указывает на возможный доступ постороннего."
            )
            events.append(Event("OUTSIDER_IN_CASH_ZONE", a, desc,
                                [samples[idx].t], {samples[idx].t: ("multi", [
                                    (c.x, c.y, c.w, c.h) for c in others[idx]])}))

        # ---- D2b: посторонний в зоне досягаемости кассира ---------------------------
        flags = []
        for s, o, cc in zip(samples, others, cashier_comp):
            if not s.valid or cc is None:
                flags.append(None); continue
            near = [c for c in o if math.hypot(c.cx - acx, c.cy - acy) < CLOSE_FACTOR * scale_ref
                    and c.area >= 0.012 * aw * ah]
            flags.append(len(near) > 0)
        for a, b in _runs(flags, times, CLOSE_MIN_SEC):
            idx = min(range(len(samples)), key=lambda k: abs(samples[k].t - a) )
            near = [c for c in others[idx]]
            desc = (
                f"С {a:.1f} с рядом с рабочим местом кассира (в пределах досягаемости) "
                f"находится человек, не являющийся кассиром, не менее {b - a:.0f} с. "
                f"Клиент должен находиться по другую сторону стола; присутствие вплотную к "
                f"кассиру может означать доступ постороннего в кассовую зону."
            )
            events.append(Event("OUTSIDER_IN_CASH_ZONE", a, desc, [samples[idx].t],
                                {samples[idx].t: ("multi", [(c.x, c.y, c.w, c.h) for c in near])}))
        return self._dedupe(events), meta

    @staticmethod
    def _static_blobs(samples):
        """Центры силуэтов, которые не двигаются всё видео (ложные срабатывания на технике)."""
        n = len([s for s in samples if s.valid])
        if n < 5:
            return []
        grid = {}
        for s in samples:
            if not s.valid:
                continue
            for c in s.comps:
                key = (round(c.cx / 12), round(c.cy / 12))
                grid.setdefault(key, []).append((c.cx, c.cy))
        out = []
        for key, pts in grid.items():
            if len(pts) >= 0.85 * n:
                arr = np.array(pts)
                if arr.std(axis=0).max() < 4:
                    out.append((float(arr[:, 0].mean()), float(arr[:, 1].mean())))
        return out

    @staticmethod
    def _dedupe(events):
        events.sort(key=lambda e: e.t)
        out = []
        for e in events:
            if out and out[-1].rule_id == e.rule_id and e.t - out[-1].t < 5.0:
                continue
            out.append(e)
        return out

    # ---------------------------------------------------------------- evidence
    def _build_violations(self, path, events, an_size, full_size):
        if not events:
            return []
        aw, ah = an_size; W, H = full_size
        kx, ky = W / float(aw), H / float(ah)
        cap = cv2.VideoCapture(path)
        src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        # последовательное чтение: seek по времени в .mov (VFR/смещённые таймстемпы) ненадёжен
        need = {}
        for e in events:
            for t in sorted(set(round(x, 2) for x in e.evidence_ts))[:3]:
                need.setdefault(int(round(t * src_fps)), []).append(t)
        raw = {}
        if need:
            last = max(need)
            i = 0
            while i <= last and cap.grab():
                if i in need:
                    ok, f = cap.retrieve()
                    if ok:
                        raw[i] = f
                i += 1
        cap.release()
        res = []
        for e in events:
            frames = []
            for t in sorted(set(round(x, 2) for x in e.evidence_ts))[:3]:
                f = raw.get(int(round(t * src_fps)))
                if f is None:
                    continue
                key = min(e.boxes, key=lambda k: abs(k - t)) if e.boxes else None
                box = e.boxes.get(key) if key is not None and abs(key - t) < 0.2 else None
                f = self._annotate(f, t, box, kx, ky, e.rule_id)
                frames.append({"timestamp_sec": round(t, 1), "image_base64": _jpeg_b64(f)})
            if not frames:
                continue
            ct = CATALOG[e.rule_id]
            res.append({
                "type": ct.title,
                "timecode_sec": round(e.t, 1),
                "description": e.description,
                "evidence_frames": frames,
                "regulation": ct.regulation,
            })
        return res

    @staticmethod
    def _annotate(f, t, box, kx, ky, rule_id):
        f = f.copy()
        color = (32, 0, 128) if rule_id == "CASHIER_LEFT" else (0, 128, 255)   # BGR
        def rect(b, label=None):
            x, y, w, h = b
            p1 = (int(x * kx), int(y * ky)); p2 = (int((x + w) * kx), int((y + h) * ky))
            cv2.rectangle(f, p1, p2, color, max(2, f.shape[1] // 300))
        if isinstance(box, tuple) and len(box) == 4 and not isinstance(box[0], str):
            rect(box)
        elif isinstance(box, tuple) and box and box[0] == "multi":
            for b in box[1]:
                rect(b)
        label = f"{t:.1f} c"
        sc = max(0.8, f.shape[1] / 900)
        cv2.rectangle(f, (0, 0), (int(150 * sc), int(34 * sc)), (0, 0, 0), -1)
        cv2.putText(f, label, (int(8 * sc), int(25 * sc)), cv2.FONT_HERSHEY_SIMPLEX, sc * 0.8,
                    (255, 255, 255), 2, cv2.LINE_AA)
        return f
